var express = require('express');
var app = express();
const path = require('path');
var fs = require('fs');
var mongoose = require('mongoose');

//몽고디비
var MongoClient = require('mongodb').MongoClient;

//데이터베이스 객체를 위한 변수
var database;
//데이터베이스 스키마 객체 변수
var UserSchema;
//데이터베이스 모델 객체
var UserModel;


//포트번호
var port = 5091;
//로그
var winston = require('winston');
//데이터 교환
const bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: false }))
app.locals.pretty = true;
app.use(express.static('static'))
app.set('view engine', 'jade');
app.set('views', './views');


//데이터베이스 연결
function connectDB() {
    //데이터베이스 연결 정보
    var databaseUrl = 'mongodb://localhost:27017/local';

    //데이터베이스 연결
    //mongoose.Promise = global.Promise;
    //mongoose.connect(databaseUrl);
    //database = mongoose.connection;

    //database.on('error', console.error.bind(console, 'mongoose connection error'));
    //database.on('open', function () {
        //logger.log('info', "데이터베이스 연결... : " + databaseUrl);
        //스키마정의
        //UserSchema = mongoose.Schema({
            //id: { type: String, required: true, unique: true },
            //password: { type: String, required: true },
            //name: String,
            //phone: String,
            //birth: String,
            //mail: String
        //});
        //console.log("스키마 정의..");

        //usermodel 정의
        //UserModel = mongoose.model("user", UserSchema);
        //console.log("UserModel 정의...");
    //});

    //연결이 끊어졌을경우 5초 후 연결
    //database.on('disconnected', function () {
        //console.log('연결이 끊김...5초 후 재연결...');
        //setInterval(connectDB, 5000);
    //});

    //데이터베이스 연결
    MongoClient.connect(databaseUrl, function (err, db) {
        if (err)
            //throw err;

        logger.log('info', '데이터베이스 연결,,, : ' + databaseUrl);

        //database 변수에 할당
        database = db.db('local');//데이터베이스 폴더명
    });
}

//아이디 비밀번호 비교(로그인)데이터베이스
var authUSer = function (database, id, password, callback) {
    console.log('authUser 호출');

    //user 컬렉션 참조
    var user = database.collection('user');

    //아이디와 비밀번호를 사용해 검색
    user.find({ "id": id, "password": password }).toArray(function (err, docs) {
        if (err) {
            callback(err, null);
            return;
        }
        if (docs.length > 0) {
            console.log('아이디[%s] 비밀번호[%s]가 일치', id, password);
            callback(null, docs);
        }
        else {
            console.log('일치하는 사용자 없음');
            callback(null, null);
        }
    });
}

//회원가입데이터베이스
var addUser = function (database, id, password, name, birth, phone, mail, callback) {
    console.log("회원가입 요청 : " + id + ' , ' + password + ' , ' + name + ' , ' + birth + ' , ' + phone + ' , ' + mail);

    //user 컬렉션 참조
    var user = database.collection('user');

    //usermodel 인스턴스
    //var userdb = new UserModel({ "id": id, "password": password, "name": name, "birth": birth, "phone": phone, "mail": mail});

    //save()로 저장
    //userdb.save(function (err) {
        //if (err) {
           // callback(err, null);
            //return;
       // }
       // console.log("사용자 회원가입..");
        //callback(null, userdb);
   // });

    //사용자 추가
    user.insertMany([{ "id": id, "password": password, "name": name, "birth": birth, "phone": phone, "mail": mail }], function (err, result) {
    if (err) {
    //오류 발생
    callback(err, null);
    return;
    }


    //오류가 아닌경우
    if (result.insertedCount > 0) {
    console.log("사용자 추가 : " + result.insertedCount);
    }
     else {
    console.log("사용자 추가 취소");
    }
    callback(null, result);
    });
};

//아이디 검색
var findUserID = function (database, name, birth, callback) {
    console.log("findUSer 요청");

    //user 컬렉션 참조
    var user = database.collection('user');

    //이름, 생일 사용해 검색
    user.find({ "name": name, "birth" : birth }).toArray(function (err, docs) {
        if (err) {
            callback(err, null);
            return;
        }
        if (docs.length > 0) {
            console.log('일치');
            callback(null, docs);
        }
        else {
            console.log('일치하는 사용자 없음');
            callback(null, null);
        }
    });
};

//로그
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.json(),
    transports: [
        // console
        new (winston.transports.Console)(),
        // file
        new winston.transports.File({ filename: 'error.log', level: 'error' }),
        new winston.transports.File({ filename: 'serverlog.log' })
    ]
});

//로그인화면
app.get('/', (req, res) => {
 res.sendFile(path.join(__dirname + '/loginweb.html'));
    logger.log('info', "[로그인화면]" + req.connection.remoteAddress);
})
app.post('/loginweb', (req, res) => {

    var id = req.body.idtext;
    var pw = req.body.pwtext;
    var pwre = req.body.pwretext;
    var birth = req.body.bdtext;
    var phone = req.body.phtext;
    var name = req.body.ntext;
    var email = req.body.mtext;

    //데이터베이스 가입 요청
    if (database) {
        addUser(database, id, pw, name, birth, phone, email, function (err, result) {

            if (err) {
                throw err;
            }

            if (result && result.insertedCount > 0) {
                console.dir(result);
                logger.log('info', "[회원가입성공]" + req.connection.remoteAddress
                    + "[ID] " + id + "[PW] " + pw + "[PW확인] " + pwre + "[생년월일] " + birth + "[전화번호] " + phone + "[이름] " + name + "[이메일] " + email);

                fs.readFile('loginweb.html', function (error, data) {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(data);
                });
            }
            else {
                logger.log('info', "[회원가입실패]" + req.connection.remoteAddress);

                fs.readFile('loginweb.html', function (error, data) {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(data);
                });
            }

        });
    } else {
        res.writeHead('200', { 'Content-Type': 'text/html;charset=utf8' });
        res.wirte('<h1>데이터베이스 연결실패</h1>');
        res.end();
    }
});

//메인화면
app.get('/main', (req, res) => {
  var id = req.query.id;
  var pw = req.query.pw;
  res.send(`id : ${id}, pw : ${pw}`);
})
app.post('/main', (req, res) => {
    var id = req.body.id;
    var pw = req.body.pw;

    if (database) {
        authUSer(database, id, pw, function (err, docs) {
            if (err) { throw err; }

            if (docs) {
                console.dir(docs);

                logger.log('info', "[로그인 성공]" + req.connection.remoteAddress + "[접속자ID] " + id + "[접속자PW] " + pw);
                fs.readFile('main.html', function (error, data) {
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(data);
                });
            }
            else {
                res.writeHead('200', { 'Content-Type': 'text/html;charset=utf8' });
                res.write('<h1>로그인실패</h1>');
                res.write("<br><br><a href='/'>다시 로그인하기</a>");
                res.end();
            }
        });
    } else {
        res.writeHead('200', { 'Content-Type': 'text/html;charset=utf8' });
        res.wirte('<h1>데이터베이스 연결실패</h1>');
        res.end();
    }


});

//회원가입
app.get('/account', function(request, response) {
  fs.readFile('make.html', function (error, data){
	response.writeHead(200, { 'Content-Type': 'text/html' });
	response.end(data);
	});
    logger.log('info', "[회원가입화면]" + request.connection.remoteAddress);
});

//아이디찾기
app.get('/findID', function(request, response) {
  fs.readFile('searchid.html', function (error, data){
	response.writeHead(200, { 'Content-Type': 'text/html' });
	response.end(data);
	});
    logger.log('info', "[아이디 찾기]" + request.connection.remoteAddress);
});
app.post('/idresult', (request, response) => {
    var name = request.body.name;
    var birth = request.body.birth;

    if (database) {
        findUserID(database, name, birth, function (err, docs) {
            if (err) { throw err; }

            if (docs) {
                console.dir(docs);
                //fs.readFile('idresult.html', function (error, data) {
                    //res.writeHead(200, { 'Content-Type': 'text/html' });
                    //res.end(data);
                //});
                res.writeHead('200', { 'Content-Type': 'text/html;charset=utf8' });
                res.write('<h1>발견</h1>');
                res.write(name);
                res.write(birth);
                res.end();
            }
            else {
                res.writeHead('200', { 'Content-Type': 'text/html;charset=utf8' });
                res.write('<h1>로그인실패</h1>');
                res.write("<br><br><a href='/'>다시 로그인하기</a>");
                res.end();
            }
        });
    } else {
        res.writeHead('200', { 'Content-Type': 'text/html;charset=utf8' });
        res.wirte('<h1>데이터베이스 연결실패</h1>');
        res.end();
    }

    fs.readFile('idresult.html', function (error, data) {
        response.writeHead(200, { 'Content-Type': 'text/html' });
        response.end(data);
    });
});

//비밀번호찾기
app.get('/findPW', function(request, response) {
  fs.readFile('searchpassword.html', function (error, data){
	response.writeHead(200, { 'Content-Type': 'text/html' });
	response.end(data);
	});
    logger.log('info', "[비밀번호 찾기]" + request.connection.remoteAddress);
});
app.post('/pwresult', (request, response) => {
    var name = request.body.name;
    var id = request.body.id;
    var birth = request.body.birth;
    var phone = request.body.phone;
    logger.log('info', "[비밀번호찾기]" + request.connection.remoteAddress + "[이름]" + name + "[생년월일]" + birth);

    fs.readFile('passwordresult.html', function (error, data) {
        response.writeHead(200, { 'Content-Type': 'text/html' });
        response.end(data);
    });
});
app.get('/setpassword', function(request, response) {
  fs.readFile('setpassword.html', function (error, data){
	response.writeHead(200, { 'Content-Type': 'text/html' });
	response.end(data);
	});
    logger.log('info', "[비밀번호 수정]" + request.connection.remoteAddress);
});

//화상회의
app.get('/meeting', function(request, response) {
  fs.readFile('meeting.html', function (error, data){
	response.writeHead(200, { 'Content-Type': 'text/html' });
	response.end(data);
	});
    logger.log('info', "[회의화면 접속]" + request.connection.remoteAddress);
});

//서버 실행
app.listen(port, () => {
    logger.log('info', '서버실행 [포트번호]' + port);
    //데이터베이스 연결
    connectDB();
});